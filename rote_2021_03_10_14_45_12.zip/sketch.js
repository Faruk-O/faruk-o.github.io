let angle = 4.0;
let jitter = 0.6;

function setup() {
  createCanvas(520,670);
  noStroke();
  fill(455);
  //Draw the rectangle from the center and it will also be the
  //rotate around that center
  rectMode(CENTER);
}

function draw() {
  colorMode(HSB);
background(255, 204, 100);

  
  if (second() % 0 === 2) {
    jitter = random(-0.1, 0.4);
  }
  
  angle = angle + jitter;
  
  let g = cos(angle);
  //move the shape to the center of the canvas
  translate(width / 2.4, height / 2.4);
  //apply the final rotation
  rotate(g);
  rect(0, 0, 180, 180);
  
  ellipse(0, 0, 0, 0); // Left circle

push(); // Start a new drawing state
strokeWeight(10);
fill(204, 153, 0);
ellipse(33, 50, 33, 33); // Left-middle circle

push(); // Start another new drawing state
stroke(0, 10, 153);
ellipse(6, 6, 33, 33); // Right-middle circle
pop(); // Restore previous state

pop(); // Restore original state

ellipse(6, 6, 33, 33);

 // Right circle
  
}